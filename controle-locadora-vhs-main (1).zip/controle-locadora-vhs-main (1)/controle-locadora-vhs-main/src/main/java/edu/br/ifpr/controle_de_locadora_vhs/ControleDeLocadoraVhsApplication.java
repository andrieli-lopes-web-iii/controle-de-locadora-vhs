package edu.br.ifpr.controle_de_locadora_vhs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControleDeLocadoraVhsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControleDeLocadoraVhsApplication.class, args);
	}

}
