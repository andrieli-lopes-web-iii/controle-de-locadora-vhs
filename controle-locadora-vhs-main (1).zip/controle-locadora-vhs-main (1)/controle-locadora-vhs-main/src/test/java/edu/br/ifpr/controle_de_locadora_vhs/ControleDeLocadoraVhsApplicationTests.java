package edu.br.ifpr.controle_de_locadora_vhs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleDeLocadoraVhsApplicationTests {

	@Test
	void contextLoads() {
	}

}
